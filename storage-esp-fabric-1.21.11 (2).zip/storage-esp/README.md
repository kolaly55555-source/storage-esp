# Storage ESP (Fabric 1.21.11) — private test mod

الميزات: Storage ESP (R)، Player ESP (P)، Auto Totem (G). قائمة الإعدادات: Right Shift.

## البناء
1. ثبّت JDK 21.
2. حمّل قالب Fabric الرسمي لـ 1.21.11 من https://fabricmc.net/develop/template
   وانسخ منه مجلد `gradle/` وملفي `gradlew` و `gradlew.bat` إلى هذا المجلد (Gradle wrapper).
3. تحقق من أرقام الإصدارات في gradle.properties من https://fabricmc.net/develop
4. شغّل:  ./gradlew build
   الملف الناتج: build/libs/storage-esp-1.0.0.jar
5. ضعه في مجلد mods مع Fabric API لإصدار 1.21.11.

## تجربة سريعة
./gradlew runClient

## تنبيه
لم يُجرَّب البناء داخل بيئتي (لا يوجد إنترنت)، وكود الرسم هو الجزء الأكثر عرضة للتعديل.
ارسل لي أي خطأ يظهر وسأصلحه.

استخدمه فقط في عالمك أو سيرفرك الخاص.

## بناء الـ jar بدون تثبيت شيء (GitHub Actions)
1. أنشئ مستودعاً جديداً على GitHub وارفع محتوى هذا المجلد إليه.
2. افتح تبويب Actions وانتظر انتهاء البناء.
3. نزّل الملف من Artifacts (storage-esp-jar) وضعه في مجلد mods.
