package com.example.storageesp;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * كل كود الرسم في هذا الملف فقط (واجهات الرسم تتغير كثيراً بين الإصدارات)،
 * فإذا ظهر خطأ في البناء فغالباً سيكون هنا.
 */
public class StorageEspRenderer {

    // Pipeline خطوط بدون اختبار عمق => تظهر من خلال الجدران
    private static final RenderPipeline ESP_PIPELINE = RenderPipelines.register(
            RenderPipeline.builder(RenderPipelines.RENDERTYPE_LINES_SNIPPET)
                    .withLocation(Identifier.of("storageesp", "pipeline/esp_lines"))
                    .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                    .build()
    );

    private static final RenderLayer ESP_LAYER = RenderLayer.of(
            "storageesp_lines",
            1536,
            false,
            false,
            ESP_PIPELINE,
            RenderLayer.MultiPhaseParameters.builder().build(false)
    );

    public static void render(WorldRenderContext ctx) {
        boolean storage = StorageEspClient.storageEsp && !StorageEspClient.HITS.isEmpty();
        boolean players = StorageEspClient.playerEsp;
        if (!storage && !players) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;

        Vec3d cam = mc.gameRenderer.getCamera().getCameraPos();
        MatrixStack matrices = ctx.matrices();
        VertexConsumerProvider consumers = ctx.consumers();
        VertexConsumer vc = consumers.getBuffer(ESP_LAYER);

        if (storage) {
            for (StorageEspClient.Hit hit : StorageEspClient.HITS) {
                Box box = new Box(hit.pos()).offset(-cam.x, -cam.y, -cam.z);
                VertexRendering.drawBox(matrices, vc, box, hit.r(), hit.g(), hit.b(), 1.0f);
            }
        }

        if (players) {
            float td = mc.getRenderTickCounter().getTickProgress(false);
            for (PlayerEntity p : mc.world.getPlayers()) {
                if (p == mc.player || p.isSpectator()) continue;
                Vec3d lp = p.getLerpedPos(td);
                Box box = p.getBoundingBox()
                        .offset(lp.x - p.getX(), lp.y - p.getY(), lp.z - p.getZ())
                        .offset(-cam.x, -cam.y, -cam.z);
                VertexRendering.drawBox(matrices, vc, box, 1.0f, 0.2f, 0.2f, 1.0f); // أحمر
            }
        }

        if (consumers instanceof VertexConsumerProvider.Immediate imm) {
            imm.draw(ESP_LAYER);
        }
    }
}
