package com.example.storageesp;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** قائمة بسيطة لتشغيل/إيقاف الميزات. تُغلق بزر Esc أو بزر Close. */
public class MenuScreen extends Screen {

    public MenuScreen() {
        super(Text.literal("Storage ESP"));
    }

    @Override
    protected void init() {
        int w = 200, h = 20, gap = 4;
        int x = this.width / 2 - w / 2;
        int y = this.height / 2 - 50;

        addToggle(x, y,               w, h, "Storage ESP", () -> StorageEspClient.storageEsp, v -> StorageEspClient.storageEsp = v);
        addToggle(x, y + (h + gap),   w, h, "Player ESP",  () -> StorageEspClient.playerEsp,  v -> StorageEspClient.playerEsp = v);
        addToggle(x, y + (h + gap)*2, w, h, "Auto Totem",  () -> StorageEspClient.autoTotem,  v -> StorageEspClient.autoTotem = v);

        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> this.close())
                .dimensions(x, y + (h + gap) * 3 + 8, w, h).build());
    }

    private void addToggle(int x, int y, int w, int h, String name,
                           BooleanSupplier getter, Consumer<Boolean> setter) {
        addDrawableChild(ButtonWidget.builder(label(name, getter.getAsBoolean()), b -> {
            boolean now = !getter.getAsBoolean();
            setter.accept(now);
            b.setMessage(label(name, now));
        }).dimensions(x, y, w, h).build());
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "ON" : "OFF"));
    }

    @Override
    public boolean shouldPause() {
        return false; // اللعبة تستمر أثناء فتح القائمة
    }
}
