package com.example.storageesp;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class StorageEspClient implements ClientModInitializer {

    // الوحدات (Modules)
    public static volatile boolean storageEsp = true;  // زر R
    public static volatile boolean playerEsp  = true;  // زر P
    public static volatile boolean autoTotem  = true;  // زر G

    public static final int CHUNK_RADIUS = 6;

    public record Hit(BlockPos pos, float r, float g, float b) {}
    public static final List<Hit> HITS = new CopyOnWriteArrayList<>();

    private static KeyBinding menuKey, storageKey, playerKey, totemKey;
    private static int totemCooldown = 0;

    @Override
    public void onInitializeClient() {
        menuKey    = reg("key.storageesp.open_menu",      GLFW.GLFW_KEY_RIGHT_SHIFT);
        storageKey = reg("key.storageesp.toggle_storage", GLFW.GLFW_KEY_R);
        playerKey  = reg("key.storageesp.toggle_player",  GLFW.GLFW_KEY_P);
        totemKey   = reg("key.storageesp.toggle_totem",   GLFW.GLFW_KEY_G);

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.player == null || mc.world == null) {
                HITS.clear();
                return;
            }

            while (menuKey.wasPressed()) {
                if (mc.currentScreen == null) mc.setScreen(new MenuScreen());
            }
            while (storageKey.wasPressed()) { storageEsp = !storageEsp; notify(mc, "Storage ESP", storageEsp); }
            while (playerKey.wasPressed())  { playerEsp  = !playerEsp;  notify(mc, "Player ESP",  playerEsp); }
            while (totemKey.wasPressed())   { autoTotem  = !autoTotem;  notify(mc, "Auto Totem",  autoTotem); }

            if (storageEsp) scanStorage(mc); else HITS.clear();
            if (autoTotem) runAutoTotem(mc);
        });

        WorldRenderEvents.AFTER_TRANSLUCENT.register(StorageEspRenderer::render);
    }

    private static KeyBinding reg(String name, int key) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(
                name, InputUtil.Type.KEYSYM, key, KeyBinding.Category.MISC));
    }

    private static void notify(MinecraftClient mc, String name, boolean on) {
        mc.player.sendMessage(Text.literal(name + ": " + (on ? "ON" : "OFF")), true);
    }

    // ---------- Auto Totem ----------
    private static void runAutoTotem(MinecraftClient mc) {
        if (totemCooldown > 0) { totemCooldown--; return; }
        if (mc.currentScreen != null || mc.interactionManager == null) return;

        ClientPlayerEntity player = mc.player;
        if (player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;

        for (int i = 0; i < 36; i++) {
            if (player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                // تحويل رقم خانة الحقيبة إلى رقم خانة في PlayerScreenHandler
                int slot = i < 9 ? 36 + i : i;
                // الزر 40 = تبديل مع اليد الثانية (Offhand)
                mc.interactionManager.clickSlot(
                        player.playerScreenHandler.syncId, slot, 40,
                        SlotActionType.SWAP, player);
                totemCooldown = 4; // تأخير بسيط بين العمليات
                return;
            }
        }
    }

    // ---------- Storage scan ----------
    private static void scanStorage(MinecraftClient mc) {
        HITS.clear();
        int pcx = mc.player.getChunkPos().x;
        int pcz = mc.player.getChunkPos().z;

        for (int cx = pcx - CHUNK_RADIUS; cx <= pcx + CHUNK_RADIUS; cx++) {
            for (int cz = pcz - CHUNK_RADIUS; cz <= pcz + CHUNK_RADIUS; cz++) {
                WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(cx, cz);
                if (chunk == null) continue;
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    if (be instanceof ChestBlockEntity) {
                        HITS.add(new Hit(be.getPos(), 1.0f, 0.8f, 0.0f));
                    } else if (be instanceof BarrelBlockEntity) {
                        HITS.add(new Hit(be.getPos(), 0.8f, 0.5f, 0.2f));
                    } else if (be instanceof ShulkerBoxBlockEntity) {
                        HITS.add(new Hit(be.getPos(), 0.8f, 0.3f, 1.0f));
                    } else if (be instanceof EnderChestBlockEntity) {
                        HITS.add(new Hit(be.getPos(), 0.2f, 0.9f, 0.6f));
                    } else if (be instanceof HopperBlockEntity
                            || be instanceof DispenserBlockEntity) {
                        HITS.add(new Hit(be.getPos(), 0.6f, 0.6f, 0.6f));
                    }
                }
            }
        }
    }
}
